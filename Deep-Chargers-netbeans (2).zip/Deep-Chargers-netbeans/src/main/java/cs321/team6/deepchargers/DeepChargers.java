/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package cs321.team6.deepchargers;
import javax.swing.JFrame;

/**
 *
 * @author will and trey
 */
public class DeepChargers {

    public static void main(String[] args) {
        System.out.println("Hello");
        cs321.team6.deepchargers.title.Title_Screen Title_Graphic = new cs321.team6.deepchargers.title.Title_Screen(); //creates instance of Title Screen - Trey
        Title_Graphic.setVisible(true); 
        try { // This stalls the rest of the program untill "New Game" is selected on the title screen - Trey
            Title_Graphic.waitForConfirmation();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        Title_Graphic.setVisible(false); //Once "New Game" is selected, closes the title screen - Trey
        
        
        
        JFrame window = new JFrame();
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setResizable(false);
        window.setTitle("Deep Chargers");

        GamePanel gamePanel = new GamePanel();
        window.add(gamePanel);
        window.pack();
        window.setLocationRelativeTo(null);
        window.setVisible(true);
        gamePanel.startGameThread();
    }
}

