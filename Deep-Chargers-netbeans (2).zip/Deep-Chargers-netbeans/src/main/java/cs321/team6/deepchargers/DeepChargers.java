/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package cs321.team6.deepchargers;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JFrame;

/**
 *
 * @author will and trey
 */
public class DeepChargers {

    //Private declarations for the window, panel, and graphics. This allows them to be referenced anywhere in this class - Trey
    private static JFrame window;
    private static GamePanel gamePanel;
    private static cs321.team6.deepchargers.title.Title_Screen Title_Graphic;
    private static cs321.team6.deepchargers.title.GameOver_Screen End_Graphic;
    
    public static void main(String[] args) {
        System.out.println("Hello");
        Title_Graphic = new cs321.team6.deepchargers.title.Title_Screen(); //creates instance of Title Screen - Trey
        Title_Graphic.setVisible(true); 
        try { // This stalls the rest of the program untill "New Game" is selected on the title screen - Trey
            Title_Graphic.waitForConfirmation();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        Title_Graphic.setVisible(false); //Once "New Game" is selected, closes the title screen - Trey
        StartGame(); //calls function that actually starts the instance of the game - Trey
    }
    
    public static void StartGame(){ //This function was refactorted so the game could be restarted from the Game Over screen without the player seeing the title again - Trey
        window = new JFrame();
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setResizable(false);
        window.setTitle("Deep Chargers");

        gamePanel = new GamePanel();
        window.add(gamePanel);
        window.pack();
        window.setLocationRelativeTo(null);
        window.setVisible(true);
        gamePanel.startGameThread();
        //Create instance of the game over screen (This was moved here to resolve a bug that created infinite screens - Trey
        End_Graphic = new cs321.team6.deepchargers.title.GameOver_Screen();
    }

    public static void EndGame(){ //destructor function: ends the game and insantiates the game over screen after a small delay - Trey
        Timer liltimer = new Timer();
        liltimer.schedule(new TimerTask() {
            @Override
            public void run() {
                if (End_Graphic.isVisible() == false) {
                    End_Graphic.setVisible(true);
                }
                window.setVisible(false);
                gamePanel.endGameThread();
                liltimer.cancel();
            }
        }, 500);
    }
}


